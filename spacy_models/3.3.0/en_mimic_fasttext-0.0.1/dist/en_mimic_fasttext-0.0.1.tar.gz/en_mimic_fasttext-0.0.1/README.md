| Feature | Description |
| --- | --- |
| **Name** | `en_mimic_fasttext` |
| **Version** | `0.0.1` |
| **spaCy** | `>=3.3.0,<3.4.0` |
| **Default Pipeline** |  |
| **Components** |  |
| **Vectors** | 236071 keys, 200000 unique vectors (100 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |